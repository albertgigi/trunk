    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                <small>
                    &copy; <?php echo @date("Y"); ?>
                    <a
                    target="_blank"
                        href="http://uanl.mx/"
                        title="Sitio de la Universidad Autónoma de Nuevo León"
                    >Universidad Autónoma de Nuevo León</a> | Secretaría de Desarrollo Sustentable
                </small>
                </div>
                <div class="col-sm-6">
                    <img class="pull-right" src="<?php echo base_url(); ?>assets/img/logo-dgi.png" alt="Logotipo de la DGI" title="Direcciòn General de Informática">
                </div>
            </div>
        </div>
    </footer>

<div class="blur">
</div><!--/#blur-->
</body>
</html>