<div class="row inicio-servicio">
	<div class="col-md-3">
		<a href="<?php echo site_url(); ?>">
			<img src="http://placehold.it/160x160">
		</a>	
	</div>
	
	<div class="col-md-3">Algo</div>
	<div class="col-md-3">Algo</div>
	<div class="col-md-3">Algo</div>
</div>
